﻿namespace ResortBooking.Web.ViewModels
{
    public class PieChartVM
    {
        public decimal[] Series { get; set; }
        public string[] Labels { get; set; }
    }
}
